
def post_register_types(root_module):
    root_module.add_include('"ns3/propagation-module.h"')

